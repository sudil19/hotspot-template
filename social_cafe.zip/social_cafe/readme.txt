1.Cek server Online Ofline

WALLED IP 

Ip -> Hotspot -> Walled Garden Ip List -> tambah(+) ->
Action accept
dst host  : s28.postimg.org

2.Cek Jumlah User Online

*Pastikan semua file di dalam forder hotspot.
*Pastikan ada file info.html di dalam folder hotspot.

Buat SCRIPT

System -> Scritp -> tambah(+) ->

Isi nama : user-online 
Ceklist semua Policy
Isi Source dangan kode di bawah ini:
 


/ip hotspot active
:global yoi;
:global tri;

:set yoi ([/ip hotspot active print count-only])
#menginput file ke "info.html" 
/file set hotspot/info.html contents= \
"<html><head><link href='assets/css/font-awesome.min.css' rel='stylesheet'><link href='dist/css/bootstrap.min.css' rel='stylesheet'><link href='dist/css/style.css' rel='stylesheet'><style>body{background-color:rgba(255, 255, 255, 0);}</style></head><body><h5> $yoi USER ON</h5></body></html>"


Kemudian Save 

Selanjutnya membuat Scheduler

System -> Scheduler -> tambah(+) -> 

Isi nama : coun-user-online
Interval : 00:00:05 (5 detik)
On Event : user-online
